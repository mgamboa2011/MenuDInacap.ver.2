<?php
    $con = mysqli_connect("localhost", "root", "", "menudinacap");
    
    $name = $_POST["usuario"];
    $username = $_POST["usuario"];
    $password = $_POST["contrasena"];
    $statement = mysqli_prepare($con, "INSERT INTO user (usuario, contrasena, rcontrasena) VALUES (?, ?, ?)");
    mysqli_stmt_bind_param($statement, "sss", $usuario, $contrasena, $rcontrasena);
    mysqli_stmt_execute($statement);
    
    $response = array();
    $response["success"] = true;  
    
    echo json_encode($response);
?>