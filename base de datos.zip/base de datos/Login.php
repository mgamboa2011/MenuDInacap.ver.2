<?php
    $con = mysqli_connect("localhost", "root", "", "menudinacap");
    
    $username = $_POST["username"];
    $password = $_POST["contrasena"];
    
    $statement = mysqli_prepare($con, "SELECT * FROM user WHERE username = ? AND contrasena = ?");
    mysqli_stmt_bind_param($statement, "ss", $usuario, $contrasena);
    mysqli_stmt_execute($statement);
    
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $user_id, $usuario, $contrasena, $rcontrasena);
    
    $response = array();
    $response["success"] = false;  
    
    while(mysqli_stmt_fetch($statement)){
        $response["success"] = true;  
        $response["usuario"] = $usuario;
        $response["contrasena"] = $contrasena;
        $response["rcontrasena"] = $rcontrasena;
    }
    
    echo json_encode($response);
?>